import requests

def reqproxy():
    proxy_str = "rp.proxyscrape.com:6060:2lr7zbclw0yxb9i:oehhbybk0arm0xn"
    proxy_parts = proxy_str.split(":")
    ip = proxy_parts[0]
    port = proxy_parts[1]
    user = proxy_parts[2]
    pass1 = proxy_parts[3]
    main_proxy = f'http://{user}:{pass1}@{ip}:{port}'
   
    session = requests.Session()
    session.proxies = {'http': main_proxy, 'https': main_proxy}
    
    response = session.get('https://httpbin.org/ip')
    
    if response.status_code == 200:
        # Extract and print the IP address from the response
        ip_address = response.json()['origin']
    else:
        print("Failed to retrieve IP address.")
        
    return session, ip_address
"""    
def reqproxy():
    session = requests.Session()
    response = session.get('https://httpbin.org/ip')
    
    if response.status_code == 200:
        ip_address = response.json()['origin']
    else:
        print("Failed to retrieve IP address.")     
    return session, ip_address
"""