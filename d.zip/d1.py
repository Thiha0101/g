import requests
import time
import json
from urllib.parse import urlparse
from bs4 import BeautifulSoup
from proxy import reqproxy

# Function to check if Cloudflare protection is present
def check_cloudflare(url):
    response = requests.get(url)
    if 'cf-ray' in response.headers:
        return True
    else:
        return False

# Function to check if CAPTCHA protection is present
def check_captcha(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    try:
        r = requests.get(url, headers=headers, timeout=3)
        soup = BeautifulSoup(r.text, 'html.parser')
        if len(soup.select('form[action*="/captcha/"]')) > 0:
            return True
        else:
            return False
    except:
        return False      

# Function to extract the main URL
def get_main_url(url):
    return urlparse(url).netloc

# Function to get search results URLs using Google Custom Search Engine API
def get_urls(keyword, num_results, api_key, cx, proxies=None):
    urls = []
    start = 1
    count = 1
    while len(urls) < num_results:
        params = {
            'key': api_key,
            'cx': cx,
            'q': keyword,
            'start': start
        }
        try:
            if proxies:
                session = requests.Session()
                session.proxies = proxies
                response = session.get('https://www.googleapis.com/customsearch/v1', params=params, timeout=5)
            else:
                response = requests.get('https://www.googleapis.com/customsearch/v1', params=params, timeout=5)
            results = response.json().get('items', [])
            for result in results:
                url = result['link']
                if url not in urls:
                    urls.append(url)
                    if check_cloudflare(url):
                        print(f"[{count}] {url} - Cloudflare detected\033[0;31m")                  
                    else:
                        print(f"[{count}] {url}\033[0;32m")
                    count += 1
                    if len(urls) == num_results:
                        return urls
            start += 10
        except requests.exceptions.RequestException:
            print("Request failed. Changing proxy...")
            proxies = reqproxy()
    return urls

# Function to analyze the site
def analyze_site(url):
    start_time = time.time()
    response = requests.get(url)
    end_time = time.time()
    time_elapsed = round(end_time - start_time, 2)
    print(f"[~] Analyzing site: {get_main_url(url)} - Time elapsed: {time_elapsed} seconds")

# Save URLs to a file
def save_urls_to_file(urls):
    with open('urls.txt', 'w') as file:
        for url in urls:
            file.write(url + '\n')

# Main function
def main():
    # Read keywords from file
    with open("keyword.txt", "r") as file:
        keywords = file.readlines()

    # Remove newline characters from keywords
    keywords = [keyword.strip() for keyword in keywords]

    num_results = 50
    api_key = "AIzaSyAwpgTwj99QmLfG_LTEof6t5LiMGF4HOVU"  # Enter your Google API Key
    cx = "50d3501fc92e94775"  # Enter your CX Key
    proxies = None

    for keyword in keywords:
        urls = get_urls(keyword, num_results, api_key, cx, proxies)
        save_urls_to_file(urls)
        for url in urls:
            analyze_site(url)


if __name__ == "__main__":
    main()
