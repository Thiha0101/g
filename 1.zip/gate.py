import requests
from bs4 import BeautifulSoup
import re
from fake_useragent import UserAgent
import concurrent.futures


#1747969985
#7020001198:AAFe7emM2syymzI9spT3sBNJabxpK4xTd60

def send_message(url, gateway, cloudflare_detected, captcha_detected):
    bot_token = '7020001198:AAFe7emM2syymzI9spT3sBNJabxpK4xTd60'
    chat_id = '1747969985'
    
    msg = f"Site Found: {url}\n" \
          f"Gateway: {gateway}\n" \
          f"Cloudflare: {cloudflare_detected}\n" \
          f"Captcha: {captcha_detected}\n"

    telegram_api_url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': msg,
        'parse_mode': 'HTML'
    }

    try:
        response = requests.post(telegram_api_url, data=payload)
        response.raise_for_status()
        print("Message sent successfully!")
    except requests.exceptions.RequestException as e:
        print(f"Error sending message: {e}")



def check_cloudflare(url):
    response = requests.get(url)
    if 'cf-ray' in response.headers:
        return True
    else:
        return False

def check_captcha(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    try:
        r = requests.get(url, headers=headers, timeout=3)
        soup = BeautifulSoup(r.text, 'html.parser')
        if len(soup.select('form[action*="/captcha/"]')) > 0:
            return True
        else:
            return False
    except:
        return False      

def get_random_user_agent():
    ua = UserAgent()
    return ua.random

def check_gateway(url):
    try:
        headers = {'User-Agent': get_random_user_agent()}
        response = requests.get(url, headers=headers, timeout=5)
        response.raise_for_status() 
    except requests.RequestException as e:
        print(f"Error accessing {url}: {e}")
        return None

    bsoup = BeautifulSoup(response.text, 'html.parser')

    payment_gateways = {
        'stripe': ['script', {'src': re.compile(r'.*js\.stripe\.com.*')}, {'src': re.compile(r'.*stripe.*')}],
        'paypal': ['script', {'src': re.compile(r'.*paypal.*')}, {'src': re.compile(r'.*checkout\.paypal\.com.*')}, {'src': re.compile(r'.*paypalobjects.*')}],
        'braintree': ['script', {'src': re.compile(r'.*braintree.*')}, {'src': re.compile(r'.*braintreegateway.*')}],
        'worldpay': ['script', {'src': re.compile(r'.*worldpay.*')}],
        'authnet': ['script', {'src': re.compile(r'.*authorizenet.*')}, {'src': re.compile(r'.*authorize\.net.*')}],
        'recurly': ['script', {'src': re.compile(r'.*recurly.*')}],
        'shopify': ['script', {'src': re.compile(r'.*shopify.*')}],
        'square': ['script', {'src': re.compile(r'.*square.*')}],
        'cybersource': ['script', {'src': re.compile(r'.*cybersource.*')}],
        'adyen': ['script', {'src': re.compile(r'.*adyen.*')}],
        '2checkout': ['script', {'src': re.compile(r'.*2checkout.*')}],
        'authorize.net': ['script', {'src': re.compile(r'.*authorize\.net.*')}],
        'eworldpay': ['script', {'src': re.compile(r'.*eworldpay.*')}],
        'eway': ['script', {'src': re.compile(r'.*eway.*')}],
        'bluepay': ['script', {'src': re.compile(r'.*bluepay.*')}],
    }

    detected_gateway = None

    for pg, patterns in payment_gateways.items():
        script_elements = bsoup.find_all('script', {'src': patterns[1]['src']}) if len(patterns) > 1 else []
        script_elements += bsoup.find_all('script', {'src': patterns[2]['src']}) if len(patterns) > 2 else []
        script_elements += bsoup.find_all('script', {'src': patterns[3]['src']}) if len(patterns) > 3 else []

        if bsoup.find(*patterns) or any(script_element for script_element in script_elements) or bsoup.find(string=re.compile(rf'.*{pg}.*', re.IGNORECASE)):
            detected_gateway = pg
            break

    return url, detected_gateway

def add_https_if_missing(url):
    if not url.startswith('http://') and not url.startswith('https://'):
        url = 'https://' + url
    return url


def process_url(url):
    url = url.strip()
    url = add_https_if_missing(url)

    try:
        result = check_gateway(url)
        if result and result[1]:
            url, gateway = result
            cloudflare_detected = check_cloudflare(url)
            captcha_detected = check_captcha(url)
            print(f"URL: {url}, Gateway: {gateway}, Captcha: {captcha_detected}, Cloudflare: {cloudflare_detected}")
            send_message(url, gateway,cloudflare_detected,captcha_detected)
    except Exception as e:
        print("Error:", e)

def main(num_threads):
    with open('urls.txt', 'r') as file:
        urls = file.readlines()
    with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
        executor.map(process_url, urls)
        
if __name__ == "__main__":
    num_threads = int(input('Enter Thread : ')
    main(num_threads)




    
