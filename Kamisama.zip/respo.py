import telebot
from colorama import Fore, Style
R = '\033[31m'
G = '\033[32m'

token = "6774013327:AAFf2MRVx6QyLG_2jZ2hbrPbTL2GXtbbmp8"
bot = telebot.TeleBot(token, parse_mode="HTML")


def send(amt, cc, ii, do, bank, emj, ip_address, gate, key, chat_id):
     msg1 = f'''
╔══════════════════════════╗
║  <b>𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ➜ 𝑺𝒕𝒓𝒊𝒑𝒆 {amt}</b>
║  <b>𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ➜ {key}</b>
║  <b>𝐂𝐂 ➜ <code>{cc}</code></b>                       
║  <b>𝐁𝐈𝐍 ➜ {ii}</b>                         
║  <b>𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ➜ {do}</b>              
║  <b>𝐁𝐀𝐍𝐊 ➜ {bank}</b>     
║  <b>𝐅𝐋𝐀𝐆 ➜ </b>{emj}
║  <b>𝐏𝐑𝐎𝐗𝐘 ➜{ip_address} 𝑳𝒊𝒗𝒆 ✅</b>
║  <b>𝐆𝐀𝐓𝐄 𝐁𝐘 ➜ {gate}</b>
╚══════════════════════════╝

𝗕𝗼𝘁 𝗯𝘆: <b><code>@𝘄𝗼𝗿𝗱2048</code></b>
'''
     bot.send_message(chat_id=chat_id, text=msg1, parse_mode='HTML')

